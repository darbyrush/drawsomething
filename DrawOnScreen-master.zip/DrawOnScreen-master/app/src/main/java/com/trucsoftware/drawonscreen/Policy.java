package com.trucsoftware.drawonscreen;

public class Policy {
  public boolean tomoatoesAreFruit;
  public boolean condimentsAllowed;
  public String[] approvedPackages;


}
