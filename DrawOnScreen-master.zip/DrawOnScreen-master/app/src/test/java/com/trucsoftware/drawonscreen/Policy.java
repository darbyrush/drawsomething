package com.trucsoftware.drawonscreen;

public class Policy {
}
